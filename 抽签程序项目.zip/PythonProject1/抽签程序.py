import json
import random
import os
import shutil
import csv

DATA_FILE = 'class_draw_data.json'
BACKUP_FILE = 'class_draw_data_backup.json' # 👈 新增：备份文件的名字


def init_data():
    """初始化班级数据"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)

    # 记得替换成你用小工具生成的真实名单字典哦
    students = {'1': '原子玉', '2': '鲁丁', '3': '吴滨宇', '4': '叶航宇', '5': '杨嘉磊', '6': '李思源', '7': '黄一诺', '8': '李嘉蕾', '9': '张雯萱', '10': '吴含', '11': '陈业庚', '12': '谢易', '13': '厉垚瑶', '14': '刘思虞', '15': '张陶涵', '16': '陈堃', '17': '梁语彤', '18': '乔梓函', '19': '陈怡嘉', '20': '余诗琪', '21': '尹昶竣', '22': '姜谦', '23': '韩佳梦', '24': '蒋简', '25': '郑子旋', '26': '贾宇哲', '27': '金晶晶', '28': '瞿婧雯', '29': '杜雨轩', '30': '楼镒涵', '31': '邬丽鑫', '32': '刘思颖', '33': '张晓亮', '34': '努尔扎提·马合木提', '35': '俞天健', '36': '计辰玥'}

    data = {
        "all_students": students,
        "pool_A": list(students.keys()),
        "pool_B": list(students.keys()),
        "records": {
            sid: {"name": name, "A_count": 0, "B_count": 0, "history": []}
            for sid, name in students.items()
        }
    }
    save_data(data)
    return data


def save_data(data):
    """保存数据"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


def draw_random_students(data, activity_type, activity_name, remain_need):
    """仅处理随机抽签的部分"""
    if remain_need <= 0:
        return []

    pool_key = f"pool_{activity_type}"
    pool = data[pool_key]
    all_sids = list(data["all_students"].keys())

    selected_sids = []

    if len(pool) >= remain_need:
        selected_sids = random.sample(pool, remain_need)
        for sid in selected_sids:
            pool.remove(sid)
    else:
        print(f"\n⚠️ 注意：{activity_type}池剩余候选人数({len(pool)}人)不足，已触发池子重置！")
        selected_sids.extend(pool)
        still_need = remain_need - len(pool)

        # 重置池子（剔除刚刚被选中的人）
        new_pool = [sid for sid in all_sids if sid not in selected_sids]

        additional_sids = random.sample(new_pool, still_need)
        selected_sids.extend(additional_sids)

        data[pool_key] = [sid for sid in new_pool if sid not in additional_sids]

    # 更新随机抽中者的记录
    for sid in selected_sids:
        data["records"][sid][f"{activity_type}_count"] += 1
        data["records"][sid]["history"].append(activity_name)

    return selected_sids


def print_records(data):
    """打印本学期统计表"""
    print("\n" + "=" * 50)
    print("📊 本学期班级活动参与统计表")
    print("=" * 50)
    print(f"{'学号':<5} | {'姓名':<6} | {'A类次数':<6} | {'B类次数':<6} | {'参与活动记录'}")
    print("-" * 60)
    for sid, info in data["records"].items():
        history_str = ", ".join(info["history"]) if info["history"] else "无"
        print(f"{sid:<6} | {info['name']:<6} | {info['A_count']:<8} | {info['B_count']:<8} | {history_str}")
    print("=" * 50 + "\n")


def export_to_excel(data):
    """将本学期统计表导出为 CSV 文件（可用 Excel 打开）"""
    # 导出的文件名
    filename = "本学期班级活动统计表.csv"

    # ⚠️ 敲黑板：这里的 encoding='utf-8-sig' 是魔法！
    # 如果只写 utf-8，用微软 Excel 打开时里面的中文会变成乱码。加了 -sig 就能完美解决。
    with open(filename, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)

        # 1. 先写第一行（表头）
        writer.writerow(["学号", "姓名", "A类次数", "B类次数", "参与活动记录"])

        # 2. 循环把每个人的数据写进去
        for sid, info in data["records"].items():
            # 把历史记录的列表变成一串文字，比如 "开学典礼(自愿), 运动会"
            history_str = ", ".join(info["history"]) if info["history"] else "无"

            # 写入该同学的一行数据
            writer.writerow([sid, info['name'], info['A_count'], info['B_count'], history_str])

    print(f"\n✅ 成功导出表格！文件名为：【{filename}】")
    print("💡 你现在可以去代码所在的文件夹里，直接双击用 Excel 打开它了！")

def main():
    data = init_data()
    print("🎉 欢迎使用班级活动抽签系统！")

    while True:
        print("\n请选择操作：")
        print("1. 进行抽签 (支持录入志愿者)")
        print("2. 查看本学期统计记录")
        print("3. 手动重置某个抽签池")
        print("4. 退出程序")
        print("5. ⏪ 撤回上一次抽签 (吃后悔药)")
        print("6. 📊 导出统计记录到 Excel 表格")

        choice = input("请输入选项数字：")

        if choice == '1':
            # ... (前面输入活动类型、名称、人数的代码保持不变) ...
            act_type = input("请输入活动类型 (A / B): ").strip().upper()
            if act_type not in ['A', 'B']:
                print("❌ 错误：活动类型只能是 A 或 B！")
                continue

            act_name = input("请输入活动名称: ").strip()

            try:
                total_need = int(input("请输入本次活动【总共】需要的人数: "))
                if total_need > len(data["all_students"]) or total_need <= 0:
                    print("❌ 错误：人数不合理！")
                    continue
            except ValueError:
                print("❌ 错误：请输入有效的数字！")
                continue

            volunteers = []
            print("\n💡 进入志愿者录入环节（如果没有志愿者，直接按 q 或回车跳过）")
            while True:
                vol_input = input("请输入志愿者的 学号 或 姓名: ").strip()
                if vol_input.lower() == 'q' or vol_input == '':
                    break

                found_sid = None
                if vol_input in data["all_students"]:
                    found_sid = vol_input
                else:
                    for sid, name in data["all_students"].items():
                        if name == vol_input:
                            found_sid = sid
                            break

                if found_sid:
                    if found_sid in volunteers:
                        print("⚠️ 这位同学已经登记过啦！")
                    else:
                        volunteers.append(found_sid)
                        print(f"✅ 成功添加志愿者：{found_sid} {data['all_students'][found_sid]}")
                else:
                    print("❌ 找不到该同学，请检查学号或姓名是否有误！")

            # --- 🌟 核心修改点：在真正修改数据前，进行备份 🌟 ---
            if os.path.exists(DATA_FILE):
                shutil.copyfile(DATA_FILE, BACKUP_FILE)  # 把旧的账本复制一份成备份文件

            pool_key = f"pool_{act_type}"
            for sid in volunteers:
                data["records"][sid][f"{act_type}_count"] += 1
                data["records"][sid]["history"].append(act_name + "(自愿)")
                if sid in data[pool_key]:
                    data[pool_key].remove(sid)

            remain_need = total_need - len(volunteers)
            random_selected = []
            if remain_need > 0:
                print(f"\n⏳ 还需要随机抽取 {remain_need} 人，正在抽签...")
                random_selected = draw_random_students(data, act_type, act_name, remain_need)
            elif remain_need < 0:
                print("\n⚠️ 提示：志愿人数已经超过了总需要人数哦！")
            else:
                print("\n🎉 志愿人数刚好满足要求，无需进行随机抽签！")

            # 保存更改（此时新数据会覆盖 DATA_FILE，但老数据安全地躺在 BACKUP_FILE 里）
            save_data(data)

            print("\n" + "*" * 40)
            print(f"🎯 本次【{act_name}】({act_type}类) 最终名单：")
            if volunteers:
                print("【自愿参与】:")
                for sid in volunteers:
                    print(f" - 学号: {sid}, 姓名: {data['all_students'][sid]}")
            if random_selected:
                print("【系统抽签】:")
                for sid in random_selected:
                    print(f" - 学号: {sid}, 姓名: {data['all_students'][sid]}")
            print("*" * 40)
            print(f"\n💡 当前 {act_type}池 剩余候选人数: {len(data[pool_key])}人")

        elif choice == '2':
            print_records(data)

        elif choice == '3':
            act_type = input("请输入要重置的池子类型 (A / B): ").strip().upper()
            if act_type in ['A', 'B']:
                data[f"pool_{act_type}"] = list(data["all_students"].keys())
                save_data(data)
                print(f"✅ {act_type}池 已成功手动重置为满员状态！")
            else:
                print("❌ 错误：类型只能是 A 或 B！")

        elif choice == '4':
            print("👋 再见！辛苦啦！")
            break

        # --- 🌟 新增的撤回功能块 🌟 ---
        elif choice == '5':
            if os.path.exists(BACKUP_FILE):
                # 确认撤回的二次警告，防止误触
                confirm = input("⚠️ 确定要撤回【上一次】的抽签操作吗？(输入 Y 确认，其他取消): ").strip().upper()
                if confirm == 'Y':
                    # 用备份文件覆盖掉当前的坏文件
                    shutil.copyfile(BACKUP_FILE, DATA_FILE)
                    # 让程序重新读取恢复好的数据
                    data = init_data()
                    print("✅ 撤回成功！时光倒流，已恢复到上一次抽签前的状态。")
                else:
                    print("🚫 已取消撤回。")
            else:
                print("❌ 无法撤回：没有找到备份文件（可能是你还没进行过任何抽签）。")
        elif choice == '6':
            export_to_excel(data)
        else:
            print("❌ 无效的输入，请重新选择。")


if __name__ == "__main__":
    main()